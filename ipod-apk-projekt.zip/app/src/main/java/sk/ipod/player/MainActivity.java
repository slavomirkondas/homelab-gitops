package sk.ipod.player;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private static final int PICK_REQUEST = 2;

    private WebView webView;
    private volatile MediaPlayer player;
    private volatile boolean prepared = false;
    private float volume = 0.7f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);

        webView.addJavascriptInterface(new Bridge(), "Native");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void releasePlayer() {
        MediaPlayer old = player;
        player = null;
        prepared = false;
        if (old != null) {
            try {
                old.release();
            } catch (Exception e) {
                // ignore
            }
        }
    }

    private void startPlayback(String uri) {
        releasePlayer();
        try {
            MediaPlayer mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build());
            mp.setDataSource(this, Uri.parse(uri));
            mp.setVolume(volume, volume);
            mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer m) {
                    prepared = true;
                    m.start();
                }
            });
            mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer m) {
                    webView.evaluateJavascript("window.__ended && window.__ended()", null);
                }
            });
            mp.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override
                public boolean onError(MediaPlayer m, int what, int extra) {
                    prepared = false;
                    return true;
                }
            });
            player = mp;
            mp.prepareAsync();
        } catch (Exception e) {
            player = null;
            prepared = false;
        }
    }

    private String displayName(Uri uri) {
        String name = null;
        Cursor cursor = null;
        try {
            cursor = getContentResolver().query(uri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) {
                    name = cursor.getString(index);
                }
            }
        } catch (Exception e) {
            // ignore
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
        if (name == null || name.length() == 0) {
            name = uri.getLastPathSegment();
        }
        if (name == null) {
            name = "Skladba";
        }
        return name.replaceAll("\\.[^.]+$", "");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_REQUEST || resultCode != RESULT_OK || data == null) {
            return;
        }
        List<Uri> uris = new ArrayList<Uri>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) {
                uris.add(data.getClipData().getItemAt(i).getUri());
            }
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }

        SharedPreferences prefs = getSharedPreferences("ipod", MODE_PRIVATE);
        JSONArray array;
        try {
            array = new JSONArray(prefs.getString("songs", "[]"));
        } catch (JSONException e) {
            array = new JSONArray();
        }

        for (Uri uri : uris) {
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception e) {
                // ignore
            }
            String text = uri.toString();
            boolean exists = false;
            for (int j = 0; j < array.length(); j++) {
                JSONObject item = array.optJSONObject(j);
                if (item != null && text.equals(item.optString("url"))) {
                    exists = true;
                }
            }
            if (!exists) {
                try {
                    JSONObject song = new JSONObject();
                    song.put("name", displayName(uri));
                    song.put("url", text);
                    array.put(song);
                } catch (JSONException e) {
                    // ignore
                }
            }
        }

        String json = array.toString();
        prefs.edit().putString("songs", json).apply();
        webView.evaluateJavascript("window.onSongsAdded(" + JSONObject.quote(json) + ")", null);
    }

    @Override
    public void onBackPressed() {
        webView.evaluateJavascript("window.ipodBack && window.ipodBack()", null);
    }

    @Override
    protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    public class Bridge {

        @JavascriptInterface
        public String getSongs() {
            return getSharedPreferences("ipod", MODE_PRIVATE).getString("songs", "[]");
        }

        @JavascriptInterface
        public void clearSongs() {
            getSharedPreferences("ipod", MODE_PRIVATE).edit().remove("songs").apply();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    releasePlayer();
                }
            });
        }

        @JavascriptInterface
        public void addSongs() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("audio/*");
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(intent, PICK_REQUEST);
                }
            });
        }

        @JavascriptInterface
        public void play(final String uri) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    startPlayback(uri);
                }
            });
        }

        @JavascriptInterface
        public void pause() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MediaPlayer mp = player;
                    if (mp != null && prepared && mp.isPlaying()) {
                        mp.pause();
                    }
                }
            });
        }

        @JavascriptInterface
        public void resume() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MediaPlayer mp = player;
                    if (mp != null && prepared) {
                        mp.start();
                    }
                }
            });
        }

        @JavascriptInterface
        public void seekTo(final int milliseconds) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    MediaPlayer mp = player;
                    if (mp != null && prepared) {
                        mp.seekTo(milliseconds);
                    }
                }
            });
        }

        @JavascriptInterface
        public void setVolume(final double level) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    volume = (float) level;
                    MediaPlayer mp = player;
                    if (mp != null) {
                        mp.setVolume(volume, volume);
                    }
                }
            });
        }

        @JavascriptInterface
        public String getState() {
            MediaPlayer mp = player;
            if (mp == null || !prepared) {
                return "{\"playing\":false,\"pos\":0,\"dur\":0}";
            }
            try {
                return String.format(Locale.US, "{\"playing\":%b,\"pos\":%.1f,\"dur\":%.1f}",
                        mp.isPlaying(), mp.getCurrentPosition() / 1000.0, mp.getDuration() / 1000.0);
            } catch (Exception e) {
                return "{\"playing\":false,\"pos\":0,\"dur\":0}";
            }
        }
    }
}
